package labproject;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import labproject.GUIDriver;

import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JTextField;
import java.awt.Color;

public class SearchingWindow extends JFrame {

	private JPanel contentPane;
	private JTextField txtEnterTargetHere;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SearchingWindow frame = new SearchingWindow();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SearchingWindow() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 807, 499);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblSelectAnyTwo = new JLabel("Select any two searching algorithms");
		lblSelectAnyTwo.setFont(new Font("Times New Roman", Font.PLAIN, 19));
		lblSelectAnyTwo.setBounds(231, 24, 301, 65);
		contentPane.add(lblSelectAnyTwo);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Linear Search", "Binary Search", "Binary Search Tree (BST)"}));
		comboBox.setFont(new Font("Times New Roman", Font.PLAIN, 19));
		comboBox.setBounds(45, 186, 245, 51);
		contentPane.add(comboBox);
		
		JLabel label = new JLabel("Algorithm # 1:");
		label.setFont(new Font("Times New Roman", Font.PLAIN, 19));
		label.setBounds(45, 144, 245, 32);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("Algorithm # 2:");
		label_1.setFont(new Font("Times New Roman", Font.PLAIN, 19));
		label_1.setBounds(511, 144, 245, 32);
		contentPane.add(label_1);
		
		JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setModel(new DefaultComboBoxModel(new String[] {"Linear Search", "Binary Search", "Binary Search Tree (BST)"}));
		comboBox_1.setFont(new Font("Times New Roman", Font.PLAIN, 19));
		comboBox_1.setBounds(511, 186, 245, 51);
		contentPane.add(comboBox_1);
		
		JComboBox comboBox_2 = new JComboBox();
		comboBox_2.setModel(new DefaultComboBoxModel(new String[] {"None","Bubble Sort", "Selection Sort", "Merge Sort", "Quick Sort"}));
		comboBox_2.setFont(new Font("Times New Roman", Font.PLAIN, 19));
		comboBox_2.setBounds(45, 265, 245, 51);
		contentPane.add(comboBox_2);
		
		JComboBox comboBox_3 = new JComboBox();
		comboBox_3.setModel(new DefaultComboBoxModel(new String[] {"None","Bubble Sort", "Selection Sort", "Merge Sort", "Quick Sort"}));
		comboBox_3.setFont(new Font("Times New Roman", Font.PLAIN, 19));
		comboBox_3.setBounds(511, 265, 245, 51);
		contentPane.add(comboBox_3);
		
		JLabel lblSelectTargetElement = new JLabel("Select Target Element:");
		lblSelectTargetElement.setFont(new Font("Times New Roman", Font.PLAIN, 19));
		lblSelectTargetElement.setBounds(178, 86, 180, 32);
		contentPane.add(lblSelectTargetElement);
		
		txtEnterTargetHere = new JTextField();
		txtEnterTargetHere.setBounds(358, 89, 174, 32);
		contentPane.add(txtEnterTargetHere);
		txtEnterTargetHere.setColumns(10);
		
		JButton button = new JButton("Compare");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GUIDriver GV = new GUIDriver(); //New instance of GUIDriver
				//Setting Sorting and Searching algorithms
				GV.setSorting1(comboBox_2.getSelectedItem());
				GV.setSorting2(comboBox_3.getSelectedItem());
				GV.setSearch1(comboBox.getSelectedItem());
				GV.setSearch2(comboBox_1.getSelectedItem());
				GV.setTarget(txtEnterTargetHere.getText());
				//performing sort and search
				GV.sort1();
				GV.sort2();
				GV.search1();
				GV.search2();
				GV.setBig01();
				GV.setBig02();
				//Moving to ResultWindow with Results
				ResultWindow RW = new ResultWindow();
				RW.textField.setText(GV.getS());
				RW.setSize(1300,1000);
			    RW.setLocationRelativeTo(null);
			    RW.setVisible(true);
			    RW.textField_1.setText(GV.found1?"Element Found":"Element Not Found");
				RW.textField_3.setText(GV.Total1cnt);
				RW.textField_2.setText(GV.found2?"Element Found":"Element Not Found");
				RW.textField_4.setText(GV.Total2cnt);
				RW.textField_5.setText(GV.BigO1);
				RW.textField_6.setText(GV.BigO2);
			}
		});
		button.setFont(new Font("Times New Roman", Font.PLAIN, 19));
		button.setBounds(231, 361, 322, 65);
		contentPane.add(button);
		
		JLabel lblmandatory = new JLabel("*Mandatory");
		lblmandatory.setForeground(Color.RED);
		lblmandatory.setFont(new Font("Times New Roman", Font.PLAIN, 19));
		lblmandatory.setBounds(536, 86, 245, 32);
		contentPane.add(lblmandatory);
		
		JLabel lblbinarySearchWill = new JLabel("*Binary Search will QuickSort by default unless specified");
		lblbinarySearchWill.setForeground(Color.RED);
		lblbinarySearchWill.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblbinarySearchWill.setBounds(218, 327, 348, 32);
		contentPane.add(lblbinarySearchWill);
		
		JLabel lblnumberOfComparisions = new JLabel("*Number of Comparisions will be a result of sum of both Search and Sort Algorithms");
		lblnumberOfComparisions.setForeground(Color.RED);
		lblnumberOfComparisions.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblnumberOfComparisions.setBounds(123, 11, 529, 32);
		contentPane.add(lblnumberOfComparisions);
	}
}
