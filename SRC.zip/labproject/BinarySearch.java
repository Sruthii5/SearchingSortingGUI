package labproject;

class BinarySearch<T> implements SearchingInterface<T> { 
	
	public int counter;
	
//-----------------------------------------------------------------------------------------	
//  Binary Search
//-----------------------------------------------------------------------------------------
	// Returns boolean if the target is present in arr[] or not,
	// true if found false if not found
	public boolean search(T arr[], T target) 
    { 
        int l = 0, r = arr.length - 1; 
        while (l <= r) {
        	counter++;
            int m = l + (r - l) / 2; 
            
            if (arr[1].getClass().getName() == "java.lang.String") {
            	// Check if target is present at mid 
            	if (arr[m].toString().compareTo(target.toString()) == 0)  
            	return true;
            	

            	// If target is smaller, ignore right half 
            	else if (arr[m].toString().compareTo(target.toString()) > 0) 
            		r = m - 1;

            
            	// If target greater, ignore left half
            	else 
            		l = m + 1;           	
            }
            else if (arr[1].getClass().getName() == "java.lang.Integer") {
            	// Check if target is present at mid 
            	if (arr[m].equals(target))  
            	return true;
            	

            	// If target is smaller, ignore right half 
            	else if ((int)arr[m] > (int)target) 
            		r = m - 1;

            
            	// If target greater, ignore left half
            	else 
            		l = m + 1;
            }
            else if (arr[1].getClass().getName() == "java.lang.Float") {
            	// Check if target is present at mid 
            	if (arr[m].equals(target))
            	return true;
            	

            	// If target is smaller, ignore right half 
            	else if ((Float)arr[m] > (Float)target) 
            		r = m - 1;

            
            	// If target greater, ignore left half
            	else 
            		l = m + 1;
            }
        } 
  
        // if we reach here, then element was not found 
        return false; 
    }
//-----------------------------------------------------------------------------------------
}
