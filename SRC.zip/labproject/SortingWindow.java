package labproject;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import labproject.GUIDriver;

import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

@SuppressWarnings("serial")
public class SortingWindow extends JFrame {
	String[] S;
	int[] I;
	Float[] F;
	char Datatype;
	private JPanel contentPane;
	JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SortingWindow frame = new SortingWindow();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SortingWindow() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 901, 552);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblSelectAnyTwo = new JLabel("Select any two sorting algorithms");
		lblSelectAnyTwo.setFont(new Font("Times New Roman", Font.PLAIN, 19));
		lblSelectAnyTwo.setBounds(288, 46, 301, 65);
		contentPane.add(lblSelectAnyTwo);
		
		JComboBox<Object> comboBox = new JComboBox<Object>();
		comboBox.setFont(new Font("Times New Roman", Font.PLAIN, 19));
		comboBox.setModel(new DefaultComboBoxModel<Object>(new String[] {"Bubble Sort", "Selection sort", "Merge Sort", "Quick Sort"}));
		comboBox.setBounds(83, 189, 245, 51);
		contentPane.add(comboBox);
		
		JComboBox<Object> comboBox_1 = new JComboBox<Object>();
		comboBox_1.setFont(new Font("Times New Roman", Font.PLAIN, 19));
		comboBox_1.setModel(new DefaultComboBoxModel<Object>(new String[] {"Bubble Sort", "Selection Sort", "Merge Sort", "Quick Sort"}));
		comboBox_1.setBounds(549, 189, 245, 51);
		contentPane.add(comboBox_1);
		
		JLabel lblAlgorithm = new JLabel("Algorithm # 1:");
		lblAlgorithm.setFont(new Font("Times New Roman", Font.PLAIN, 19));
		lblAlgorithm.setBounds(83, 147, 245, 32);
		contentPane.add(lblAlgorithm);
		
		JLabel lblAlgorithm_1 = new JLabel("Algorithm # 2:");
		lblAlgorithm_1.setFont(new Font("Times New Roman", Font.PLAIN, 19));
		lblAlgorithm_1.setBounds(549, 147, 245, 32);
		contentPane.add(lblAlgorithm_1);
		
		JButton btnNewButton = new JButton("Compare");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GUIDriver GV = new GUIDriver(); //new instance of GUIDriver
				//Setting Sorting algorithms
				GV.setSorting1(comboBox.getSelectedItem());
				GV.setSorting2(comboBox_1.getSelectedItem());
				ResultWindow RW = new ResultWindow();
				RW.textField.setText(GV.getS());
				//Perform sort and Big-O
				GV.sort1();
				GV.sort2();
				GV.setBig01();
				GV.setBig02();
				//Moving to resultwindow with results
				RW.setSize(1300,1000);
			    RW.setLocationRelativeTo(null);
			    RW.setVisible(true);
				RW.textField_1.setText(GV.getS1());
				RW.textField_3.setText(GV.Sorting1cnt);
				RW.textField_2.setText(GV.getS2());
				RW.textField_4.setText(GV.Sorting2cnt);
				RW.textField_5.setText(GV.BigO1);
				RW.textField_6.setText(GV.BigO2);
			}
		});
		btnNewButton.setFont(new Font("Times New Roman", Font.PLAIN, 19));
		btnNewButton.setBounds(267, 324, 322, 65);
		contentPane.add(btnNewButton);
		
		textField = new JTextField();
		textField.setVisible(false);
		textField.setBounds(83, 105, 751, 32);
		contentPane.add(textField);
		textField.setColumns(10);
	}
}
