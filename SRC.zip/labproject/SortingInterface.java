package labproject;

public interface SortingInterface<T> {
	
	// Method for sorting
	void sort(T arr[],int low,int high);

}
