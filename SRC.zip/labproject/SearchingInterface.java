package labproject;

public interface SearchingInterface<T> {
	
	// Method performs searching operations
	boolean search(T arr[], T target);

}
