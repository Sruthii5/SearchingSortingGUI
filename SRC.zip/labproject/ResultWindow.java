package labproject;

import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import labproject.GUIDriver;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

@SuppressWarnings("serial")
public class ResultWindow extends JFrame {

	private JPanel contentPane;
	JTextField textField;
	JTextField textField_1;
	JTextField textField_2;
	JTextField textField_3;
	JTextField textField_4;
	JTextField textField_5;
	JTextField textField_6;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ResultWindow frame = new ResultWindow();
					frame.setVisible(true);
					frame.setSize(1300,1000);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ResultWindow() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1237, 772);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblAlgorithm_1 = new JLabel("Algorithm # 1 Result:");
		lblAlgorithm_1.setFont(new Font("Times New Roman", Font.PLAIN, 19));
		lblAlgorithm_1.setBounds(121, 190, 245, 32);
		contentPane.add(lblAlgorithm_1);
		
		JLabel lblAlgorithm = new JLabel("Algorithm # 2 Result:");
		lblAlgorithm.setFont(new Font("Times New Roman", Font.PLAIN, 19));
		lblAlgorithm.setBounds(870, 190, 245, 32);
		contentPane.add(lblAlgorithm);
		
		textField = new JTextField();
		textField.setBounds(84, 84, 1064, 87);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblInput = new JLabel("Input ::");
		lblInput.setFont(new Font("Times New Roman", Font.PLAIN, 19));
		lblInput.setBounds(536, 26, 178, 32);
		contentPane.add(lblInput);
		
		textField_1 = new JTextField();
		textField_1.setBounds(84, 238, 431, 213);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(717, 238, 431, 213);
		contentPane.add(textField_2);
		
		JLabel lblSortedList = new JLabel(":: Sorted List ::");
		lblSortedList.setFont(new Font("Times New Roman", Font.PLAIN, 19));
		lblSortedList.setBounds(561, 313, 134, 58);
		contentPane.add(lblSortedList);
		
		JLabel lblNumberOfComparisions = new JLabel(":: Number of comparisions ::");
		lblNumberOfComparisions.setFont(new Font("Times New Roman", Font.PLAIN, 19));
		lblNumberOfComparisions.setBounds(504, 499, 245, 51);
		contentPane.add(lblNumberOfComparisions);
		
		JLabel lblBigO = new JLabel(":: Big O notation ::");
		lblBigO.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblBigO.setBounds(536, 598, 165, 40);
		contentPane.add(lblBigO);
		
		textField_3 = new JTextField();
		textField_3.setBounds(84, 494, 375, 58);
		contentPane.add(textField_3);
		textField_3.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(773, 498, 375, 58);
		contentPane.add(textField_4);
		
		JLabel lblSearchResult = new JLabel(":: Search Result ::");
		lblSearchResult.setFont(new Font("Times New Roman", Font.PLAIN, 19));
		lblSearchResult.setBounds(561, 356, 134, 58);
		contentPane.add(lblSearchResult);
		
		textField_5 = new JTextField();
		textField_5.setColumns(10);
		textField_5.setBounds(84, 580, 375, 58);
		contentPane.add(textField_5);
		
		textField_6 = new JTextField();
		textField_6.setColumns(10);
		textField_6.setBounds(773, 580, 375, 58);
		contentPane.add(textField_6);
	}
}

