package labproject;

public class BubbleSort<T> implements SortingInterface<T> {

	public int count;
//---------------------------------------------------------------------------------------
// Bubble sort
//---------------------------------------------------------------------------------------
		public void sort(T arr[],int start,int end) {  
			count = 0;
			int n = arr.length;  // length of the array
			System.out.println(n);
			System.out.println(end);
	        T temp = null;   // temporary variable to swap elements
	        
	        for(int i=0; i < n; i++) { 
	        	count++;
	        	for(int j=1; j < (n-i); j++) { 
	        		count++;
	        		if (arr[1].getClass().getName() == "java.lang.String") {
	        			if((arr[j-1].toString().compareTo(arr[j].toString()))>0) {  
	        				//swap elements  
	        				temp = arr[j-1];  
	        				arr[j-1] = arr[j];  
	        				arr[j] = temp;
	        			}
	        		}
	        		else if (arr[1].getClass().getName() == "java.lang.Integer") {
	        			if ((int) arr[j-1] > (int) arr[j]) {
	        				//swap elements  
		        			temp = arr[j-1];  
		        			arr[j-1] = arr[j];  
		        			arr[j] = temp;
	        			}
	        		}
	        		else if (arr[1].getClass().getName() == "java.lang.Float") {
	        			if ((Float) arr[j-1] > (Float) arr[j]) {
	        				//swap elements  
		        			temp = arr[j-1];  
		        			arr[j-1] = arr[j];  
		        			arr[j] = temp;
	        			}
	        		}
	        }
		}
	}
}
