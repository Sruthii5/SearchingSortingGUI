package labproject;

public class SelectionSort<T> implements SortingInterface<T> {

	public int count;
//---------------------------------------------------------------------------------------
// Selection sort
//---------------------------------------------------------------------------------------
		public void sort(T arr[],int start, int end) {
	     
			count = 0;
			int n = arr.length; 
	  
	        // One by one move boundary of unsorted subarray 
	        for (int i = 0; i < n-1; i++) 
	        { 	count++;
	            // Find the minimum element in unsorted array 
	            int min_idx = i; 
	            for (int j = i+1; j < n; j++) { 
	            	count++;
	            	if (arr[1].getClass().getName() == "java.lang.String") {
	            		if (arr[j].toString().compareTo(arr[min_idx].toString()) < 0) { 
	            			min_idx = j; 
	            		}
	            	}
	            	else if (arr[1].getClass().getName() == "java.lang.Integer") {
	            		if ((int)arr[j] < (int)arr[min_idx]) { 
	            			min_idx = j; 
	            		}
	            	}
	            	else if (arr[1].getClass().getName() == "java.lang.Float") {
	            		if ((Float)arr[j] < (Float)arr[min_idx]) { 
	            			min_idx = j; 
	            		}
	            	}
	            }
	            	// Swap the found minimum element with the first element 
 
	            	T temp = arr[min_idx]; 
	            	arr[min_idx] = arr[i]; 
	            	arr[i] = temp;
	        }
	    } 
//---------------------------------------------------------------------------------------
}
