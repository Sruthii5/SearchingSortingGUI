package labproject;

public class LinearSearch<T> implements SearchingInterface<T>{
	
	public int counter=0;
	
//-----------------------------------------------------------------------------------------	
//  Linear Search
//-----------------------------------------------------------------------------------------
	// Returns boolian if the target is present in arr[] or not,
	// true if found flase if not found
	public boolean search(T[] arr, T target) {
		
		int len = arr.length;
		
		for (int i = 0 ; i < len ; i++) {
			counter++;
			if (arr[i].equals(target)) 
				return true;
			
		}
		return false;
	}
//-----------------------------------------------------------------------------------------	

}
