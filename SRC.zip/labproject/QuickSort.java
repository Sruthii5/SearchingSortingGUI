package labproject;

public class QuickSort<T> implements SortingInterface<T> {
	
	public int count = 0;
	
//-----------------------------------------------------------------------------------------	
//	    Quick Sort
//-----------------------------------------------------------------------------------------		
		
		/* This function takes last element as pivot, places the pivot element at its correct 
	   		position in sorted array, and places all smaller (smaller than pivot) to left of 
	    	pivot and all greater elements to right of pivot */
		int partition(T arr[], int low, int high) 
		{ 	
			T pivot = arr[high];  
	     	int i = (low-1); // index of smaller element 
	     	for (int j=low; j<high; j++) { 	
	     	
	     	count++;
	     		
	     	if (arr[1].getClass().getName() == "java.lang.String") {
	     		// If current element is smaller than or equal to pivot  
	     		if (arr[j].toString().compareTo(pivot.toString()) < 0 ) 
	     		{ 
	     			i++; 
	     			// swap arr[i] and arr[j] 
	     			T temp = arr[i]; 
	     			arr[i] = arr[j]; 
	     			arr[j] = temp; 
	     		}
	     	}
	     	else if (arr[1].getClass().getName() == "java.lang.Integer") {
	     		// If current element is smaller than or equal to pivot  
	     		if ((int)arr[j] < (int)pivot) 
	     		{ 
	     			i++; 
	     			// swap arr[i] and arr[j] 
	     			T temp = arr[i]; 
	     			arr[i] = arr[j]; 
	     			arr[j] = temp; 
	     		}
	     	}
	     	else if (arr[1].getClass().getName() == "java.lang.Float") {
	     		// If current element is smaller than or equal to pivot  
	     		if ((Float)arr[j] < (Float)pivot) 
	     		{ 
	     			i++; 
	     			// swap arr[i] and arr[j] 
	     			T temp = arr[i]; 
	     			arr[i] = arr[j]; 
	     			arr[j] = temp; 
	     		}
	     	}
	     	}
 

	     	// swap arr[i+1] and arr[high] (or pivot) 
	     	T temp = arr[i+1]; 
	     	arr[i+1] = arr[high]; 
	     	arr[high] = temp; 

	     	return i+1; 
		} 


		/* Function that implements QuickSort() 
	   		arr[] --> Array to be sorted, 
	   		low  --> Starting index, 
	   		high  --> Ending index */
		public void sort(T arr[], int low, int high) 
		{ 
			if (low < high) 
			{ 	
				count++;
				
				//pi is partitioning index, arr[pi] is now at right place  
	           		 
				int pivot = partition(arr, low, high); 

				// Recursively sort elements before partition and after partition 
				sort(arr, low, pivot-1); 
				sort(arr, pivot+1, high); 
			}
			else 
				count++;
		}
			
//-----------------------------------------------------------------------------------------	

}
