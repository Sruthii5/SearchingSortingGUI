package labproject;

class BinarySearchTree<T> { 
	
	public int counter = 0;
	
//-----------------------------------------------------------------------------------------	
//  Binary Search
//-----------------------------------------------------------------------------------------
	
    /* Class containing left and right child of current node and key value*/
    @SuppressWarnings("hiding")
	public class Node<T> { 
        T key; 
        Node<T> left, right; 
  
        public Node(T item) { 
            key = item; 
            left = right = null; 
        } 
    } 
  
    // Root of BST 
    Node<T> root; 
  
    // Constructor 
    BinarySearchTree() {  
        root = null;  
    } 
  
    // This method mainly calls insertRec() 
    void insert(T key) { 
       root = insertRec(root, key); 
    } 
      
    /* A recursive function to insert a new key in BST */
    Node<T> insertRec(Node<T> root, T key) { 
  
        /* If the tree is empty, return a new node */
        if (root == null) { 
            root = new Node<T>(key); 
            return root; 
        } 
        
        
        if (key.getClass().getName() == "java.lang.String") {
        /* Otherwise, recur down the tree */
        if (key.toString().compareTo(root.key.toString()) < 0) 
            root.left = insertRec(root.left, key); 
        else if (key.toString().compareTo(root.key.toString()) > 0) 
            root.right = insertRec(root.right, key); 
  
        /* return the (unchanged) node pointer */
        return root;
        }
        else if (key.getClass().getName() == "java.lang.Integer") {
            /* Otherwise, recur down the tree */
            if ((int)key < (int)root.key) 
                root.left = insertRec(root.left, key); 
            else if ((int)key > (int)root.key) 
                root.right = insertRec(root.right, key); 
      
            /* return the (unchanged) node pointer */
            return root;
        }
        else {
            /* Otherwise, recur down the tree */
            if ((Float)key < (Float)root.key) 
                root.left = insertRec(root.left, key); 
            else if ((Float)key > (Float)root.key) 
                root.right = insertRec(root.right, key); 
      
            /* return the (unchanged) node pointer */
            return root;
        }
    } 
  
    // This method mainly calls InorderRec() 
    void inorder()  { 
       inorderRec(root); 
    } 
  
    // A utility function to do inorder traversal of BST 
    void inorderRec(Node<T> root) { 
        if (root != null) { 
            inorderRec(root.left); 
            System.out.println(root.key); 
            inorderRec(root.right); 
        } 
    }
    
    public boolean search(Node<T> root, T key) 
    { 
        counter++;
    	
        if (key.getClass().getName() == "java.lang.String") {
        // Base Cases: root is null or key is present at root 
        if (root==null) 
            return false;
      
        // val is greater than root's key 
        else if (root.key.toString().compareTo(key.toString()) > 0) 
        	return search(root.left, key); 
        
        // val is less than root's key
        else if (root.key.toString().compareTo(key.toString()) < 0)
        	return search(root.right, key); 
        
        else
        	return true;
        }
        else if (key.getClass().getName() == "java.lang.Integer") {
            // Base Cases: root is null or key is present at root 
            if (root==null) 
                return false;
          
            // val is greater than root's key 
            else if ((int)root.key > (int)key) 
            	return search(root.left, key); 
            
            // val is less than root's key
            else if ((int)root.key < (int)key)
            	return search(root.right, key); 
            
            else
            	return true;
            }
        else {
            // Base Cases: root is null or key is present at root 
            if (root==null) 
                return false;
          
            // val is greater than root's key 
            else if ((Float)root.key > (Float)key) 
            	return search(root.left, key); 
            
            // val is less than root's key
            else if ((Float)root.key < (Float)key)
            	return search(root.right, key); 
            
            else
            	return true;
            }
    }
}