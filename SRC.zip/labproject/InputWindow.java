package labproject;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;

import labproject.GUIDriver;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JScrollBar;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class InputWindow extends JFrame {
	protected static final String GV = null;
	String S = "";
	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					InputWindow window = new InputWindow();
					window.frame.setVisible(true);
					window.setSize(750,750);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public InputWindow() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	void initialize() {
		frame = new JFrame();
		frame.getContentPane().setFont(new Font("Times New Roman", Font.PLAIN, 19));
		frame.setBounds(100, 100, 1210, 681);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblSelectDataType = new JLabel("Select a Data Type");
		lblSelectDataType.setFont(new Font("Times New Roman", Font.PLAIN, 19));
		lblSelectDataType.setBounds(54, 41, 158, 50);
		frame.getContentPane().add(lblSelectDataType);
		
		JRadioButton rdbtnString = new JRadioButton("String");
		rdbtnString.setFont(new Font("Times New Roman", Font.PLAIN, 19));
		rdbtnString.setBounds(263, 56, 105, 21);
		frame.getContentPane().add(rdbtnString);
		
		JRadioButton rdbtnInteger = new JRadioButton("Integer");
		rdbtnInteger.setFont(new Font("Times New Roman", Font.PLAIN, 19));
		rdbtnInteger.setBounds(415, 56, 105, 21);
		frame.getContentPane().add(rdbtnInteger);
		
		JRadioButton rdbtnFloatingPoint = new JRadioButton("Floating Point");
		rdbtnFloatingPoint.setFont(new Font("Times New Roman", Font.PLAIN, 19));
		rdbtnFloatingPoint.setBounds(563, 56, 174, 21);
		frame.getContentPane().add(rdbtnFloatingPoint);
		
		JLabel lblInputAnArry = new JLabel("Input an array ::");
		lblInputAnArry.setFont(new Font("Times New Roman", Font.PLAIN, 19));
		lblInputAnArry.setBounds(54, 213, 158, 50);
		frame.getContentPane().add(lblInputAnArry);
		
		JTextArea txtrEnterDataHere = new JTextArea();
		txtrEnterDataHere.setFont(new Font("Monospaced", Font.PLAIN, 16));
		txtrEnterDataHere.setText("Enter data here");
		txtrEnterDataHere.setBounds(246, 228, 853, 284);
		frame.getContentPane().add(txtrEnterDataHere);
		
		JLabel lblImportFromFile = new JLabel("Import from file ::");
		lblImportFromFile.setFont(new Font("Times New Roman", Font.PLAIN, 19));
		lblImportFromFile.setBounds(54, 133, 174, 50);
		frame.getContentPane().add(lblImportFromFile);
		
		JButton btnImport = new JButton("Import");
		btnImport.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFileChooser fileChooser = new JFileChooser("."); //To Import File
				fileChooser.addActionListener(new ActionListener() {
				      public void actionPerformed(ActionEvent e) {
				        System.out.println("Action");
				      }
				});
				int status = fileChooser.showOpenDialog(null); //Browse dialog box for file selection
			    if (status == JFileChooser.APPROVE_OPTION) {
			      File selectedFile = fileChooser.getSelectedFile(); //selecting file
			      try {
					Scanner sc = new Scanner (selectedFile); //Reading file
					
					while (sc.hasNextLine()) {
						S = S + sc.nextLine() + " ";
					}
					txtrEnterDataHere.setText(S); //Displaying selected file in input field
					sc.close();
				} catch (FileNotFoundException e1) {
					e1.printStackTrace();
				}			      
			    } else if (status == JFileChooser.CANCEL_OPTION) {
			      System.out.println("calceled");
			}
			}
		});
		btnImport.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnImport.setBounds(243, 148, 85, 21);
		frame.getContentPane().add(btnImport);
		
		JLabel lblSelectSortingOr = new JLabel("Select Sorting or searching");
		lblSelectSortingOr.setFont(new Font("Times New Roman", Font.PLAIN, 19));
		lblSelectSortingOr.setBounds(54, 568, 274, 50);
		frame.getContentPane().add(lblSelectSortingOr);
		
		JButton btnSorting = new JButton("Sorting");
		btnSorting.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				S = txtrEnterDataHere.getText(); //Setting S to input field values
				GUIDriver GV = new GUIDriver(); //new instance of GUIDriver
				SortingWindow frame1 = new SortingWindow();
				if (rdbtnString.isSelected()) { //String input
					GV.incrementRC();
					GV.setS1(S);
					GV.setS2(S);
					GV.setDT('S');
				}
				if (rdbtnInteger.isSelected()){ //Integer input
					GV.incrementRC();
					GV.setI1(S);
					GV.setI2(S);
					GV.setDT('I');
				}
				if (rdbtnFloatingPoint.isSelected()){ //Float input
					GV.incrementRC();
					GV.setF1(S);
					GV.setF2(S);
					GV.setDT('F');
				}
				if (GV.getRC() == 1) { //If a single datatype is selected
					System.out.println("Good Job");
					//moving to SortingWindow
					frame1.setSize(1000,750);
				    frame1.setLocationRelativeTo(null);
				    frame1.setVisible(true); 
					frame.dispose();
				}
				else //if more than 1 datatype is selected INVALID
					System.out.println("Select one of the data types");
			}
		});
		btnSorting.setFont(new Font("Times New Roman", Font.PLAIN, 19));
		btnSorting.setBounds(338, 570, 360, 48);
		frame.getContentPane().add(btnSorting);
		
		JButton btnSearching = new JButton("Searching");
		btnSearching.setFont(new Font("Times New Roman", Font.PLAIN, 19));
		btnSearching.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				S = txtrEnterDataHere.getText(); //Setting S to input field values
				GUIDriver GV = new GUIDriver();//new instance of GUIDriver
				SearchingWindow frame1 = new SearchingWindow();
				if (rdbtnString.isSelected()) {//String input
					GV.incrementRC();
					GV.setS1(S);
					GV.setS2(S);
					GV.setDT('S');
				}
				if (rdbtnInteger.isSelected()){//Integer input
					GV.incrementRC();
					GV.setI1(S);
					GV.setI2(S);
					GV.setDT('I');
				}
				if (rdbtnFloatingPoint.isSelected()){//Float input
					GV.incrementRC();
					GV.setF1(S);
					GV.setF2(S);
					GV.setDT('F');
				}
				if (GV.getRC() == 1) {//If a single datatype is selected VALID
					System.out.println("Good Job");
					//moving to SearchWindow
					frame1.setSize(1000,750);	
				    frame1.setLocationRelativeTo(null);
				    frame1.setVisible(true); 
					frame.dispose();
				}
				else //if more than 1 datatype is selected INVALID
					System.out.println("Select one of the data types");
			}
		});
		btnSearching.setBounds(720, 570, 360, 48);
		frame.getContentPane().add(btnSearching);
		
		
		JScrollBar scrollBar_1 = new JScrollBar();
		scrollBar_1.setBounds(1109, 228, 17, 284);
		frame.getContentPane().add(scrollBar_1);
		
		JLabel lblselectOnlyOne = new JLabel("*Select only one datatype");
		lblselectOnlyOne.setForeground(Color.RED);
		lblselectOnlyOne.setFont(new Font("Times New Roman", Font.PLAIN, 19));
		lblselectOnlyOne.setBounds(251, 11, 342, 50);
		frame.getContentPane().add(lblselectOnlyOne);
	}

	public void setSize(int i, int j) {
		// TODO Auto-generated method stub
		
	}
}
