package labproject;

public class MergeSort<T> implements SortingInterface<T> {
	
//-----------------------------------------------------------------------------------------	
//  Merge Sort
//-----------------------------------------------------------------------------------------	
	int count = 0;
	// Merges two halfs of arr[].  
    void merge(T arr[], int start, int mid, int end) 
    { 	
    	
        int length1 = mid - start + 1; // length of first half
        int length2 = end - mid; // length of second half
  
        // Create temporary arrays 
        @SuppressWarnings("unchecked")
		T[] L = (T[]) new Object[length1];
        @SuppressWarnings("unchecked")
		T[] R = (T[]) new Object[length2];
  
        /*Copy data to temp arrays*/
        for (int i=0; i<length1; ++i) 
            L[i] = arr[start + i]; 
        for (int j=0; j<length2; ++j) 
            R[j] = arr[mid + 1+ j]; 
  
  
        /* Merge the temp arrays */
  
        // Initial indexes of first and second subarrays 
        int i = 0, j = 0; 
  
        // Initial index of merged subarry array 
        int k = start; 
        while (i < length1 && j < length2) 
        { 	count++;
        if (arr[1].getClass().getName() == "java.lang.String") {
            if (L[i].toString().compareTo(R[j].toString()) < 0) 
            { 
                arr[k] = L[i]; 
                i++;
            } 
           	else
           	{ 
               	arr[k] = R[j]; 
               	j++;
           	} 
           	k++; 
        }
        else if (arr[1].getClass().getName() == "java.lang.Integer") {
        	if ((int) L[i] < (int) R[j])
            { 
                arr[k] = L[i]; 
                i++;
            } 
           	else
           	{ 
               	arr[k] = R[j]; 
               	j++;
           	} 
           	k++;
        }
        else if (arr[1].getClass().getName() == "java.lang.Float") {
        	if ((Float) L[i] < (Float) R[j])
            { 
                arr[k] = L[i]; 
                i++;
            } 
           	else
           	{ 
               	arr[k] = R[j]; 
               	j++;
           	} 
           	k++;
        }
        }
  
        /* Copy remaining elements of L[] if any */
        while (i < length1) 
        { 
            arr[k] = L[i]; 
            i++; 
            k++;
            count++;
        } 
  
        /* Copy remaining elements of R[] if any */
        while (j < length2) 
        { 
            arr[k] = R[j]; 
            j++; 
            k++;
            count++;
        } 
    } 
  
    // Recursive sort alogorithm
    public void sort(T arr[], int start, int end) 
    { 
        if (start < end) 
        { 	
        	count++;
            // Find the middle point 
            int mid = (start+end)/2; 
  
            // Sort first and second halves 
            sort(arr, start, mid); 
            sort(arr , mid+1, end); 
  
            // Merge the sorted halves 
            merge(arr, start, mid, end); 
        } 
    }

//-----------------------------------------------------------------------------------------	

}
