package labproject;

/*
 * GUIDriver is the class which holds all data methods
 * required for GUI implementation
 */
public class GUIDriver<T> {
	/*A total of 28 variables declared
	 *Most variables repeat as there are two separate algorithms to be executed and displayed
	 *Many variables are declared static so that a new instance of GUIDriver can make use of
	 *static variables set by previous application windows
	 */
	static String[] S1;
	static String[] S2;
	static Integer[] I1;
	static Integer[] I2;
	static Float[] F1;
	static Float[] F2;
	static String St0 ="";
	static String St1 ="";
	static String St2 ="";
	static char Datatype;
	static int RadioCount = 0;
	static String Sorting1="";
	static String Sorting2="";
	static String Search1="";
	static String Search2="";
	public static boolean found1;
	public static boolean found2;
	static String targetS;
	static Integer targetI;
	static Float targetF;
	public int S1cnt;
	public String Sorting1cnt;
	public String Sorting2cnt;
	public String Search1cnt;
	public String Search2cnt;
	public String Total1cnt;
	public String Total2cnt;
	public String BigO1;
	public String BigO2;
	//GETTERS and SETTERS
	public void setS1 (String S) {
		GUIDriver.S1=null;
		GUIDriver.S1 = S.split(" ");
		GUIDriver.Datatype = 'S';
	}
	public void setS2 (String S) {
		GUIDriver.S2=null;
		GUIDriver.S2 = S.split(" ");
		GUIDriver.Datatype = 'S';
	}
	public void setI1 (String I) {	
		S1 = I.split(" ");
		GUIDriver.I1 = new Integer[S1.length];
		for (int i =0; i< S1.length; i++) {
			GUIDriver.I1[i] = Integer.parseInt(S1[i]);
		}
		GUIDriver.Datatype = 'I';
	}
	public void setI2 (String I) {	
		S2 = I.split(" ");
		GUIDriver.I2 = new Integer[S2.length];
		for (int i =0; i< S2.length; i++) {
			GUIDriver.I2[i] = Integer.parseInt(S2[i]);
		}
		GUIDriver.Datatype = 'I';
	}
	public void setF1 (String F) {	
		S1 = F.split(" ");
		GUIDriver.F1 = new Float[S1.length];
		for (int i =0; i< S1.length; i++) {
			GUIDriver.F1[i] = Float.parseFloat(S1[i]);
		}
		GUIDriver.Datatype = 'F';
	}	
	public void setF2 (String F) {	
		S2 = F.split(" ");
		GUIDriver.F2 = new Float[S2.length];
		for (int i =0; i< S2.length; i++) {
			GUIDriver.F2[i] = Float.parseFloat(S2[i]);
		}
		GUIDriver.Datatype = 'F';
	}	
	public String[] getSS() {
		for (int i = 0; i<S1.length; i++) {
			St1 = St1 + S1[i];
		}
		return S1;
	}
	public String getS() {
		for (int i = 0; i<S1.length; i++) {
			St0 = St0 + S1[i] + "\n";
		}
		return St0;
	}
	public String getS1() {
		for (int i = 0; i<S1.length; i++) {
			St1 = St1 + S1[i] + "\n";
		}
		return St1;
	}
	public String getS2() {
		for (int i = 0; i<S2.length; i++) {
			St2 = St2 + S2[i] + "\n";
		}
		return St2;
	}
	public Integer[] getI() {
		return I1;
	}
	public Float[] getF() {
		return F1;
	}
	public void incrementRC() {
		GUIDriver.RadioCount++;
	}
	public int getRC() {
		return RadioCount;
	}
	public void setSorting1 (Object object) {	
		GUIDriver.Sorting1 = (String) object;
	}
	public String getSorting1() {
		return Sorting1;
	}
	public void setSorting2 (Object object) {	
		GUIDriver.Sorting2 = (String) object;
	}
	public String getSorting2() {
		return Sorting2;
	}
	public void setSearch1 (Object object) {	
		GUIDriver.Search1 = (String) object;
	}
	public void setSearch2 (Object object) {	
		GUIDriver.Search2 = (String) object;
	}
	public void setDT (char ch) {
		GUIDriver.Datatype = ch;
	}
	//Method to set target for search algorithms
	public void setTarget(String target) {
		if (Datatype == 'S')
			GUIDriver.targetS = target;
		if (Datatype == 'I')
			GUIDriver.targetI = Integer.parseInt(target);
		if (Datatype == 'F')
			GUIDriver.targetF = Float.parseFloat(target);
	}
	//Big-O for 1st algorithm
	public void setBig01 () {
		if (Sorting1.equalsIgnoreCase("bubble Sort") || Sorting1.equalsIgnoreCase("Selection sort") )
			this.BigO1 = "O(N^2)";
		if (Sorting1.equalsIgnoreCase("Merge Sort")|| Sorting1.equalsIgnoreCase("Quick sort"))
			this.BigO1 = "O(NLogN)";
		if (Search1.equalsIgnoreCase("Linear Search"))
			this.BigO1 = "O(N)";
		if (Search1.equalsIgnoreCase("Binary Search"))
			this.BigO1 = "O(LogN)";
		if (Search1.equalsIgnoreCase("Binary Search Tree (BST)"))
			this.BigO1 = "O(h)";
	}
	//Big-O for 2nd algorithm
	public void setBig02 () {
		if (Sorting2.equalsIgnoreCase("bubble Sort") || Sorting2.equalsIgnoreCase("Selection sort") )
			this.BigO2 = "O(N^2)";
		if (Sorting2.equalsIgnoreCase("Merge Sort")|| Sorting2.equalsIgnoreCase("Quick sort"))
			this.BigO2 = "O(NLogN)";
		if (Search2.equalsIgnoreCase("Linear Search"))
			this.BigO2 = "O(N)";
		if (Search2.equalsIgnoreCase("Binary Search"))
			this.BigO2 = "O(LogN)";
		if (Search2.equalsIgnoreCase("Binary Search Tree (BST)"))
			this.BigO2 = "O(h)";
	}
	//method for 1st algorithm sorting
	public void sort1() {
		if (Datatype == 'S') { //String datatype sorting
		if (Sorting1.equalsIgnoreCase("bubble Sort")) {
			BubbleSort<String> BSS = new BubbleSort<String>();
			BSS.sort(S1, 0, S1.length-1);
			Sorting1cnt = Integer.toString(BSS.count);
		}
		if (Sorting1.equalsIgnoreCase("Selection sort")) {
			SelectionSort<String> SSS = new SelectionSort<String>();
			SSS.sort(S1, 0, S1.length-1);
			Sorting1cnt = Integer.toString(SSS.count);
		}
		if (Sorting1.equalsIgnoreCase("Merge Sort")) {
			MergeSort<String> MSS = new MergeSort<String>();
			MSS.sort(S1, 0, S1.length-1);
			Sorting1cnt = Integer.toString(MSS.count);
		}
		if (Sorting1.equalsIgnoreCase("Quick Sort")) {
			QuickSort<String> QSS = new QuickSort<String>();
			QSS.sort(S1, 0, S1.length-1);
			Sorting1cnt = Integer.toString(QSS.count);
		}
		}
		if (Datatype == 'I') { //Integer datatype sorting
			if (Sorting1.equalsIgnoreCase("bubble Sort")) {
				BubbleSort<Integer> BSI = new BubbleSort<Integer>();
				BSI.sort(I1, 0, I1.length-1);
				Sorting1cnt = Integer.toString(BSI.count);
				for (int i = 0; i<I1.length; i++) {
					S1[i] = Integer.toString(I1[i]);
				}
			}
			if (Sorting1.equalsIgnoreCase("Selection sort")) {
				SelectionSort<Integer> SSI = new SelectionSort<Integer>();
				SSI.sort(I1, 0, I1.length-1);
				Sorting1cnt = Integer.toString(SSI.count);
				for (int i = 0; i<I1.length; i++) {
					S1[i] = Integer.toString(I1[i]);
				}
			}
			if (Sorting1.equalsIgnoreCase("Merge Sort")) {
				MergeSort<Integer> MSI = new MergeSort<Integer>();
				MSI.sort(I1, 0, I1.length-1);
				Sorting1cnt = Integer.toString(MSI.count);
				for (int i = 0; i<I1.length; i++) {
					S1[i] = Integer.toString(I1[i]);
				}
			}
			if (Sorting1.equalsIgnoreCase("Quick Sort")) {
				QuickSort<Integer> QSI = new QuickSort<Integer>();
				QSI.sort(I1, 0, I1.length-1);
				Sorting1cnt = Integer.toString(QSI.count);
				for (int i = 0; i<I1.length; i++) {
					S1[i] = Integer.toString(I1[i]);
				}
			}
			}
		if (Datatype == 'F') { //Float datatype sorting
			if (Sorting1.equalsIgnoreCase("bubble Sort")) {
				BubbleSort<Float> BSF = new BubbleSort<Float>();
				BSF.sort(F1, 0, F1.length-1);
				Sorting1cnt = Integer.toString(BSF.count);
				for (int i = 0; i<F1.length; i++) {
					S1[i] = Float.toString(F1[i]);
				}
			}
			if (Sorting1.equalsIgnoreCase("Selection sort")) {
				SelectionSort<Float> SSF = new SelectionSort<Float>();
				SSF.sort(F1, 0, F1.length-1);
				Sorting1cnt = Integer.toString(SSF.count);
				for (int i = 0; i<F1.length; i++) {
					S1[i] = Float.toString(F1[i]);
				}
			}
			if (Sorting1.equalsIgnoreCase("Merge Sort")) {
				MergeSort<Float> MSF = new MergeSort<Float>();
				MSF.sort(F1, 0, F1.length-1);
				Sorting1cnt = Integer.toString(MSF.count);
				for (int i = 0; i<F1.length; i++) {
					S1[i] = Float.toString(F1[i]);
				}
			}
			if (Sorting1.equalsIgnoreCase("Quick Sort")) {
				QuickSort<Float> QSF = new QuickSort<Float>();
				QSF.sort(F1, 0, F1.length-1);
				Sorting1cnt = Integer.toString(QSF.count);
				for (int i = 0; i<F1.length; i++) {
					S1[i] = Float.toString(F1[i]);
				}
			}
			}
			
	}
	//method for 2nd algorithm sorting
	public void sort2() {
		if (Datatype == 'S') { //String datatype sorting
		if (Sorting2.equalsIgnoreCase("bubble Sort")) {
			BubbleSort<String> BSS = new BubbleSort<String>();
			BSS.sort(S2, 0, S2.length-1);
			Sorting2cnt = Integer.toString(BSS.count);
		}
		if (Sorting2.equalsIgnoreCase("Selection sort")) {
			SelectionSort<String> SSS = new SelectionSort<String>();
			SSS.sort(S2, 0, S2.length-1);
			Sorting2cnt = Integer.toString(SSS.count);
		}
		if (Sorting2.equalsIgnoreCase("Merge Sort")) {
			MergeSort<String> MSS = new MergeSort<String>();
			MSS.sort(S2, 0, S2.length-1);
			Sorting2cnt = Integer.toString(MSS.count);
		}
		if (Sorting2.equalsIgnoreCase("Quick Sort")) {
			QuickSort<String> QSS = new QuickSort<String>();
			QSS.sort(S2, 0, S2.length-1);
			Sorting2cnt = Integer.toString(QSS.count);
		}
		}
		if (Datatype == 'I') { //Integer datatype Sorting
			if (Sorting2.equalsIgnoreCase("bubble Sort")) {
				BubbleSort<Integer> BSI = new BubbleSort<Integer>();
				BSI.sort(I2, 0, I2.length-1);
				Sorting2cnt = Integer.toString(BSI.count);
				for (int i = 0; i<I2.length; i++) {
					S2[i] = Integer.toString(I2[i]);
				}
			}
			if (Sorting2.equalsIgnoreCase("Selection sort")) {
				SelectionSort<Integer> SSI = new SelectionSort<Integer>();
				SSI.sort(I2, 0, I2.length-1);
				Sorting2cnt = Integer.toString(SSI.count);
				for (int i = 0; i<I2.length; i++) {
					S2[i] = Integer.toString(I2[i]);
				}
			}
			if (Sorting2.equalsIgnoreCase("Merge Sort")) {
				MergeSort<Integer> MSI = new MergeSort<Integer>();
				MSI.sort(I2, 0, I2.length-1);
				Sorting2cnt = Integer.toString(MSI.count);
				for (int i = 0; i<I2.length; i++) {
					S2[i] = Integer.toString(I2[i]);
				}
			}
			if (Sorting2.equalsIgnoreCase("Quick Sort")) {
				QuickSort<Integer> QSI = new QuickSort<Integer>();
				QSI.sort(I2, 0, I2.length-1);
				Sorting2cnt = Integer.toString(QSI.count);
				for (int i = 0; i<I2.length; i++) {
					S2[i] = Integer.toString(I2[i]);
				}
			}
			}
		if (Datatype == 'F') {//Float datatype Sorting
			if (Sorting2.equalsIgnoreCase("bubble Sort")) {
				BubbleSort<Float> BSF = new BubbleSort<Float>();
				BSF.sort(F2, 0, F2.length-1);
				Sorting2cnt = Integer.toString(BSF.count);
				for (int i = 0; i<F2.length; i++) {
					S2[i] = Float.toString(F2[i]);
				}
			}
			if (Sorting2.equalsIgnoreCase("Selection sort")) {
				SelectionSort<Float> SSF = new SelectionSort<Float>();
				SSF.sort(F2, 0, F2.length-1);
				Sorting2cnt = Integer.toString(SSF.count);
				for (int i = 0; i<F2.length; i++) {
					S2[i] = Float.toString(F2[i]);
				}
			}
			if (Sorting2.equalsIgnoreCase("Merge Sort")) {
				MergeSort<Float> MSF = new MergeSort<Float>();
				MSF.sort(F2, 0, F2.length-1);
				Sorting2cnt = Integer.toString(MSF.count);
				for (int i = 0; i<F2.length; i++) {
					S2[i] = Float.toString(F2[i]);
				}
			}
			if (Sorting2.equalsIgnoreCase("Quick Sort")) {
				QuickSort<Float> QSF = new QuickSort<Float>();
				QSF.sort(F2, 0, F2.length-1);
				Sorting2cnt = Integer.toString(QSF.count);
				for (int i = 0; i<F2.length; i++) {
					S2[i] = Float.toString(F2[i]);
				}
			}
			}
			
	}
	//method for 1st searching algorithm
	public void search1 () {
		if (Datatype == 'S') { //String datatype Search
			if (Search1.equalsIgnoreCase("Linear Search")) {
				LinearSearch<String> LSS = new LinearSearch<String>();
				found1 = LSS.search(S1, targetS);
				Search1cnt = Integer.toString(LSS.counter);
			}
			if (Search1.equalsIgnoreCase("Binary Search")) {
				if (Sorting1.equalsIgnoreCase("None")) //Quick sort by default for Binary Search
				{
					QuickSort<String> QSS = new QuickSort<String>();
					QSS.sort(S1, 0, S1.length-1);
					Sorting1cnt = Integer.toString(QSS.count);
				}
				BinarySearch<String> BSS = new BinarySearch<String>();
				found1 = BSS.search(S1, targetS);
				Search1cnt = Integer.toString(BSS.counter);
			}
			if (Search1.equalsIgnoreCase("Binary Search Tree (BST)")) {
			BinarySearchTree<String> BSTS = new BinarySearchTree<String>();
			for (int i = 0; i< S1.length; i++) {
				BSTS.insert(S1[i]);
			}
			found1 = BSTS.search(BSTS.root, targetS);
			Search1cnt = Integer.toString(BSTS.counter);
			}
			if (Sorting1.equalsIgnoreCase("None") && !Search1.equalsIgnoreCase("Binary Search"))
				Total1cnt = Integer.toString(Integer.parseInt(Search1cnt));
			else
			Total1cnt = Integer.toString(Integer.parseInt(Search1cnt) + Integer.parseInt(Sorting1cnt));
			}
			if (Datatype == 'I') {//Integer datatype Search
				if (Search1.equalsIgnoreCase("Linear Search")) {
					LinearSearch<Integer> LSI = new LinearSearch<Integer>();
					found1 = LSI.search(I1, targetI);
					Search1cnt = Integer.toString(LSI.counter);
				}
				if (Search1.equalsIgnoreCase("Binary Search")) {
					if (Sorting1.equalsIgnoreCase("None"))
					{
						QuickSort<Integer> QSI = new QuickSort<Integer>();
						QSI.sort(I1, 0, I1.length-1);
						Sorting1cnt = Integer.toString(QSI.count);
						for (int i = 0; i<I1.length; i++) {
							S1[i] = Integer.toString(I1[i]);
						}
					}
					BinarySearch<Integer> BSI = new BinarySearch<Integer>();
					found1 = BSI.search(I1, targetI);
					Search1cnt = Integer.toString(BSI.counter);
				}
				if (Search1.equalsIgnoreCase("Binary Search Tree (BST)")) {
				BinarySearchTree<Integer> BSTI = new BinarySearchTree<Integer>();
				for (int i = 0; i< I1.length; i++) {
					BSTI.insert(I1[i]);
				}
				found1 = BSTI.search(BSTI.root, targetI);
				Search1cnt = Integer.toString(BSTI.counter);
				}
				if (Sorting1.equalsIgnoreCase("None") && !Search1.equalsIgnoreCase("Binary Search"))
					Total1cnt = Integer.toString(Integer.parseInt(Search1cnt));
				else
				Total1cnt = Integer.toString(Integer.parseInt(Search1cnt) + Integer.parseInt(Sorting1cnt));
				}
			if (Datatype == 'F') {//Float datatype Search
				if (Search1.equalsIgnoreCase("Linear Search")) {
					LinearSearch<Float> LSF = new LinearSearch<Float>();
					found1 = LSF.search(F1, targetF);
					Search1cnt = Integer.toString(LSF.counter);
				}
				if (Search1.equalsIgnoreCase("Binary Search")) {
					if (Sorting1.equalsIgnoreCase("None"))
					{
						QuickSort<Float> QSF = new QuickSort<Float>();
						QSF.sort(F1, 0, F1.length-1);
						Sorting1cnt = Integer.toString(QSF.count);
						for (int i = 0; i<F1.length; i++) {
							S1[i] = Float.toString(F1[i]);
						}
					}
					BinarySearch<Float> BSF = new BinarySearch<Float>();
					found1 = BSF.search(F1, targetF);
					Search1cnt = Integer.toString(BSF.counter);
				}
				if (Search1.equalsIgnoreCase("Binary Search Tree (BST)")) {
					BinarySearchTree<Float> BSTF = new BinarySearchTree<Float>();
					for (int i = 0; i< F1.length; i++) {
						BSTF.insert(F1[i]);
					}
					found1 = BSTF.search(BSTF.root, targetF);
					Search1cnt = Integer.toString(BSTF.counter);
				}
				if (Sorting1.equalsIgnoreCase("None") && !Search1.equalsIgnoreCase("Binary Search"))
					Total1cnt = Integer.toString(Integer.parseInt(Search1cnt));
				else
				Total1cnt = Integer.toString(Integer.parseInt(Search1cnt) + Integer.parseInt(Sorting1cnt));
				}
	}
	//method for 2nd searching algorithm
	public void search2 () {
		if (Datatype == 'S') {//String datatype Search
			if (Search2.equalsIgnoreCase("Linear Search")) {
				LinearSearch<String> LSS = new LinearSearch<String>();
				found2 = LSS.search(S2, targetS);
				Search2cnt = Integer.toString(LSS.counter);
			}
			if (Search2.equalsIgnoreCase("Binary Search")) {
				if (Sorting2.equalsIgnoreCase("None"))
				{
					QuickSort<String> QSS = new QuickSort<String>();
					QSS.sort(S2, 0, S2.length-1);
					Sorting2cnt = Integer.toString(QSS.count);
				}
				BinarySearch<String> BSS = new BinarySearch<String>();
				found2 = BSS.search(S2, targetS);
				Search2cnt = Integer.toString(BSS.counter);
			}
			if (Search2.equalsIgnoreCase("Binary Search Tree (BST)")) {
				BinarySearchTree<String> BSTS = new BinarySearchTree<String>();
				for (int i = 0; i< S2.length; i++) {
					BSTS.insert(S2[i]);
				}
				found2 = BSTS.search(BSTS.root, targetS);
				Search2cnt = Integer.toString(BSTS.counter);
			}
			if (Sorting2.equalsIgnoreCase("None") && !Search2.equalsIgnoreCase("Binary Search"))
				Total2cnt = Integer.toString(Integer.parseInt(Search2cnt));
			else
				Total2cnt = Integer.toString(Integer.parseInt(Search2cnt) + Integer.parseInt(Sorting2cnt));
			}
			if (Datatype == 'I') {//Integer datatype Search
				if (Search2.equalsIgnoreCase("Linear Search")) {
					LinearSearch<Integer> LSI = new LinearSearch<Integer>();
					found2 = LSI.search(I2, targetI);
					Search2cnt = Integer.toString(LSI.counter);
				}
				if (Search2.equalsIgnoreCase("Binary Search")) {
					if (Sorting2.equalsIgnoreCase("None"))
					{
						QuickSort<Integer> QSI = new QuickSort<Integer>();
						QSI.sort(I2, 0, I2.length-1);
						Sorting2cnt = Integer.toString(QSI.count);
						for (int i = 0; i<I2.length; i++) {
							S2[i] = Integer.toString(I2[i]);
						}
					}
					BinarySearch<Integer> BSI = new BinarySearch<Integer>();
					found2 = BSI.search(I2, targetI);
					Search2cnt = Integer.toString(BSI.counter);
				}
				if (Search2.equalsIgnoreCase("Binary Search Tree (BST)")) {
					BinarySearchTree<Integer> BSTI = new BinarySearchTree<Integer>();
					for (int i = 0; i< I2.length; i++) {
						BSTI.insert(I2[i]);
					}
					found2 = BSTI.search(BSTI.root, targetI);
					Search2cnt = Integer.toString(BSTI.counter);
				}
				if (Sorting2.equalsIgnoreCase("None") && !Search2.equalsIgnoreCase("Binary Search"))
					Total2cnt = Integer.toString(Integer.parseInt(Search2cnt));
				else
					Total2cnt = Integer.toString(Integer.parseInt(Search2cnt) + Integer.parseInt(Sorting2cnt));
				}
			if (Datatype == 'F') {//Float datatype Search
				if (Search2.equalsIgnoreCase("Linear Search")) {
					LinearSearch<Float> LSF = new LinearSearch<Float>();
					found2 = LSF.search(F2, targetF);
					Search2cnt = Integer.toString(LSF.counter);
				}
				if (Search2.equalsIgnoreCase("Binary Search")) {
					if (Sorting2.equalsIgnoreCase("None"))
					{
						QuickSort<Float> QSF = new QuickSort<Float>();
						QSF.sort(F2, 0, F2.length-1);
						Sorting2cnt = Integer.toString(QSF.count);
						for (int i = 0; i<F1.length; i++) {
							S2[i] = Float.toString(F2[i]);
						}
					}
					BinarySearch<Float> BSF = new BinarySearch<Float>();
					found2 = BSF.search(F2, targetF);
					Search2cnt = Integer.toString(BSF.counter);
				}
				if (Search2.equalsIgnoreCase("Binary Search Tree (BST)")) {
					BinarySearchTree<Float> BSTF = new BinarySearchTree<Float>();
					for (int i = 0; i< F2.length; i++) {
						BSTF.insert(F2[i]);
					}
					found2 = BSTF.search(BSTF.root, targetF);
					Search2cnt = Integer.toString(BSTF.counter);
				}
				if (Sorting2.equalsIgnoreCase("None") && !Search2.equalsIgnoreCase("Binary Search"))
					Total2cnt = Integer.toString(Integer.parseInt(Search2cnt));
				else
					Total2cnt = Integer.toString(Integer.parseInt(Search2cnt) + Integer.parseInt(Sorting2cnt));
				}
	}
}
